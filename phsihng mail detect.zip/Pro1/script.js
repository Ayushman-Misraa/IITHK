let phishingModel = {
    words: {},
    totalPhishing: 0,
    totalLegitimate: 0
};

// Load and process training data
function loadTrainingData() {
    Papa.parse("emails.csv", {
        download: true,
        header: true,
        skipEmptyLines: true,
        complete: function(results) {
            processTrainingData(results.data);
            document.getElementById('emlFile').disabled = false;
        }
    });
}

function processTrainingData(data) {
    data.forEach(row => {
        const isPhishing = row.Prediction === '1';
        if (isPhishing) phishingModel.totalPhishing++;
        else phishingModel.totalLegitimate++;

        for (const [word, count] of Object.entries(row)) {
            if (word === 'Email No.' || word === 'Prediction') continue;
            
            if (!phishingModel.words[word]) {
                phishingModel.words[word] = {
                    phishing: 0,
                    legitimate: 0
                };
            }
            
            if (isPhishing) {
                phishingModel.words[word].phishing += parseInt(count);
            } else {
                phishingModel.words[word].legitimate += parseInt(count);
            }
        }
    });

    // Calculate probabilities with Laplace smoothing
    const smoothing = 1;
    Object.keys(phishingModel.words).forEach(word => {
        const w = phishingModel.words[word];
        w.pPhishing = (w.phishing + smoothing) / 
                      (phishingModel.totalPhishing + 2 * smoothing);
        w.pLegitimate = (w.legitimate + smoothing) / 
                       (phishingModel.totalLegitimate + 2 * smoothing);
    });
}

function analyzeEmail() {
    const fileInput = document.getElementById('emlFile');
    const resultDiv = document.getElementById('result');
    
    if (!fileInput.files.length) {
        resultDiv.innerHTML = '⚠️ Please select an .eml file first';
        resultDiv.style.color = 'orange';
        return;
    }

    const file = fileInput.files[0];
    const reader = new FileReader();

    reader.onload = function(e) {
        const emailContent = e.target.result;
        const isPhishing = classifyEmail(emailContent);
        
        resultDiv.innerHTML = isPhishing 
            ? '⚠️ Phishing Email Detected!'
            : '✅ Legitimate Email';
        resultDiv.style.color = isPhishing ? 'red' : 'green';
    };

    reader.readAsText(file);
}

function classifyEmail(emailContent) {
    // Simple email content parsing
    const body = emailContent
        .replace(/Content-Transfer-Encoding:.*?\r\n\r\n/gs, '') // Remove encoding headers
        .replace(/=\r\n/g, '') // Remove soft line breaks
        .replace(/=3D/g, '=') // Basic quoted-printable decoding
        .toLowerCase();
    
    const words = body.match(/\b\w+\b/g) || [];
    
    // Calculate probabilities
    let logPPhishing = Math.log(phishingModel.totalPhishing / 
                              (phishingModel.totalPhishing + phishingModel.totalLegitimate));
    let logPLegitimate = Math.log(phishingModel.totalLegitimate / 
                                (phishingModel.totalPhishing + phishingModel.totalLegitimate));

    words.forEach(word => {
        if (phishingModel.words[word]) {
            logPPhishing += Math.log(phishingModel.words[word].pPhishing);
            logPLegitimate += Math.log(phishingModel.words[word].pLegitimate);
        }
    });

    return logPPhishing > logPLegitimate;
}

// Initialize when page loads
window.addEventListener('load', () => {
    loadTrainingData();
    document.getElementById('emlFile').addEventListener('change', function(e) {
        document.getElementById('fileName').textContent = e.target.files[0].name;
    });
});