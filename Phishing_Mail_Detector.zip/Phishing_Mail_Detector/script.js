let phishingModel = {
    words: {},
    totalPhishing: 0,
    totalLegitimate: 0
};

// Load and process training data
function loadTrainingData() {
    Papa.parse("emails.csv", {
        download: true,
        header: true,
        skipEmptyLines: true,
        complete: function(results) {
            processTrainingData(results.data);
            document.getElementById('emlFile').disabled = false;
        },
        error: function(err) {
            console.error('Error loading training data:', err);
        }
    });
}

function processTrainingData(data) {
    data.forEach(row => {
        const isPhishing = row.Prediction === '1';
        if (isPhishing) phishingModel.totalPhishing++;
        else phishingModel.totalLegitimate++;

        for (const [word, count] of Object.entries(row)) {
            if (word === 'Email No.' || word === 'Prediction') continue;
            
            if (!phishingModel.words[word]) {
                phishingModel.words[word] = {
                    phishing: 0,
                    legitimate: 0
                };
            }
            
            if (isPhishing) {
                phishingModel.words[word].phishing += parseInt(count);
            } else {
                phishingModel.words[word].legitimate += parseInt(count);
            }
        }
    });

    // Calculate probabilities with Laplace smoothing
    const smoothing = 1;
    Object.keys(phishingModel.words).forEach(word => {
        const w = phishingModel.words[word];
        w.pPhishing = (w.phishing + smoothing) / 
                      (phishingModel.totalPhishing + 2 * smoothing);
        w.pLegitimate = (w.legitimate + smoothing) / 
                       (phishingModel.totalLegitimate + 2 * smoothing);
    });
}

function analyzeEmail() {
    const fileInput = document.getElementById('emlFile');
    const resultDiv = document.getElementById('result');
    const analyzeBtn = document.querySelector('.analyze-btn');
    const loader = analyzeBtn.querySelector('.loader');
    const btnText = analyzeBtn.querySelector('.btn-text');
    
    if (!fileInput.files.length) {
        showResult('⚠️ Please select an .eml file first', 'warning');
        return;
    }

    // Show loading state
    btnText.style.opacity = '0';
    loader.style.display = 'block';
    analyzeBtn.disabled = true;

    const file = fileInput.files[0];
    const reader = new FileReader();

    reader.onload = function(e) {
        const emailContent = e.target.result;
        const isPhishing = classifyEmail(emailContent);
        
        // Simulate processing delay
        setTimeout(() => {
            showResult(
                isPhishing ? 'Phishing Email Detected' : 'Legitimate Email',
                isPhishing ? 'phishing' : 'legitimate'
            );
            
            // Reset button
            btnText.style.opacity = '1';
            loader.style.display = 'none';
            analyzeBtn.disabled = false;
        }, 1500);
    };

    reader.onerror = function(error) {
        console.error('File reading error:', error);
        showResult('❌ Error reading file', 'error');
        btnText.style.opacity = '1';
        loader.style.display = 'none';
        analyzeBtn.disabled = false;
    };

    reader.readAsText(file);
}

function classifyEmail(emailContent) {
    // Simple email content parsing
    const body = emailContent
        .replace(/Content-Transfer-Encoding:.*?\r\n\r\n/gs, '')
        .replace(/=\r\n/g, '')
        .replace(/=3D/g, '=')
        .toLowerCase();
    
    const words = body.match(/\b\w+\b/g) || [];
    
    // Calculate probabilities
    let logPPhishing = Math.log(phishingModel.totalPhishing / 
                              (phishingModel.totalPhishing + phishingModel.totalLegitimate));
    let logPLegitimate = Math.log(phishingModel.totalLegitimate / 
                                (phishingModel.totalPhishing + phishingModel.totalLegitimate));

    words.forEach(word => {
        if (phishingModel.words[word]) {
            logPPhishing += Math.log(phishingModel.words[word].pPhishing);
            logPLegitimate += Math.log(phishingModel.words[word].pLegitimate);
        }
    });

    return logPPhishing > logPLegitimate;
}

function showResult(text, type) {
    const resultDiv = document.getElementById('result');
    const icon = resultDiv.querySelector('.result-icon');
    const textElement = resultDiv.querySelector('.result-text');
    
    resultDiv.className = `result-card visible ${type}`;
    textElement.textContent = text;
    
    // Set icon
    icon.innerHTML = type === 'phishing' ?
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>' :
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>';
}

// Initialize when page loads
window.addEventListener('load', () => {
    loadTrainingData();
    
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('emlFile');

    // Drag and drop handlers
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = getComputedStyle(document.documentElement)
            .getPropertyValue('--primary');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.style.borderColor = 'rgba(255, 255, 255, 0.1)';
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        fileInput.files = e.dataTransfer.files;
        document.getElementById('fileName').textContent = fileInput.files[0].name;
        dropZone.style.borderColor = 'rgba(255, 255, 255, 0.1)';
    });

    fileInput.addEventListener('change', function(e) {
        document.getElementById('fileName').textContent = e.target.files[0]?.name || '';
    });
});